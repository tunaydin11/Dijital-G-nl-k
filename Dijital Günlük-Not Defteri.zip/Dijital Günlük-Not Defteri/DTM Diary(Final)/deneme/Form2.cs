﻿using Guna.UI2.WinForms;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace deneme
{
    public partial class Form2 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );

        public Form2()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(
                CreateRoundRectRgn(0, 0, Width, Height, 20, 20)
            );
        }

        int mouseX, mouseY;

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Left = MousePosition.X - mouseX;
            this.Top = MousePosition.Y - mouseY;
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            timer1.Enabled = false;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseX = MousePosition.X - this.Left;
            mouseY = MousePosition.Y - this.Top;
            timer1.Enabled = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }

        private void FormuTemizle()
        {
            guna2TextBox1.Text = "";
            guna2TextBox2.Text = "";
            guna2TextBox3.Text = "";
            guna2TextBox4.Text = "";
            guna2TextBox5.Text = "";
            radioButton1.Checked = false;
            radioButton3.Checked = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            guna2TextBox4.PasswordChar = '\u25CF';
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (guna2TextBox4.PasswordChar == '\0')
            {
                guna2TextBox4.PasswordChar = '\u25CF';
            }
            else
            {
                guna2TextBox4.PasswordChar = '\0';
            }
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            string ad = guna2TextBox1.Text.Trim();
            string soyad = guna2TextBox2.Text.Trim();
            string kullaniciAdi = guna2TextBox3.Text.Trim();
            string sifre = guna2TextBox4.Text.Trim();
            string ePosta = guna2TextBox5.Text.Trim();
            bool cinsiyetSecildi = radioButton1.Checked || radioButton3.Checked;

            if (string.IsNullOrEmpty(ad) ||
                string.IsNullOrEmpty(soyad) ||
                string.IsNullOrEmpty(kullaniciAdi) ||
                string.IsNullOrEmpty(sifre) ||
                string.IsNullOrEmpty(ePosta) ||
                !cinsiyetSecildi)
            {
                MessageBox.Show(
                    "Lütfen tüm kayıt alanlarını doldurun.",
                    "Eksik Bilgi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            bool cinsiyetDegeri = radioButton1.Checked;
            Class1 bgln = new Class1();

            string kontrolQuery = @"SELECT COUNT(*) 
                                    FROM Kullanici_Bilgileri 
                                    WHERE KullaniciAdi = @KullaniciAdi 
                                       OR E_Posta = @E_Posta";

            string insertQuery = @"INSERT INTO Kullanici_Bilgileri
                                   (KullaniciAdi, Ad, Soyad, Cinsiyet, Sifre, E_Posta)
                                   VALUES
                                   (@KullaniciAdi, @Ad, @Soyad, @Cinsiyet, @Sifre, @E_Posta)";

            try
            {
                using (SqlConnection baglanti = bgln.baglanti())
                {
                    baglanti.Open();

                    using (SqlCommand kontrolCmd = new SqlCommand(kontrolQuery, baglanti))
                    {
                        kontrolCmd.Parameters.Add("@KullaniciAdi", SqlDbType.NVarChar).Value = kullaniciAdi;
                        kontrolCmd.Parameters.Add("@E_Posta", SqlDbType.NVarChar).Value = ePosta;

                        int kayitVarMi = (int)kontrolCmd.ExecuteScalar();

                        if (kayitVarMi > 0)
                        {
                            MessageBox.Show(
                                "Bu Kullanıcı Adı veya E-Posta zaten kullanılıyor.",
                                "Kayıt Engellendi",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning
                            );
                            return;
                        }
                    }

                    using (SqlCommand command = new SqlCommand(insertQuery, baglanti))
                    {
                        command.Parameters.Add("@KullaniciAdi", SqlDbType.NVarChar).Value = kullaniciAdi;
                        command.Parameters.Add("@Ad", SqlDbType.NVarChar).Value = ad;
                        command.Parameters.Add("@Soyad", SqlDbType.NVarChar).Value = soyad;
                        command.Parameters.Add("@Cinsiyet", SqlDbType.Bit).Value = cinsiyetDegeri;
                        command.Parameters.Add("@Sifre", SqlDbType.NVarChar).Value = sifre;
                        command.Parameters.Add("@E_Posta", SqlDbType.NVarChar).Value = ePosta;

                        command.ExecuteNonQuery();

                        MessageBox.Show(
                            "Kayıt başarıyla eklendi!",
                            "Başarılı",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );

                        FormuTemizle();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Genel bir hata oluştu:\n" + ex.Message,
                    "Hata",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}