﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace deneme
{
    public partial class Form4 : Form
    {
        DataTable tumNotlar;
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse);

        private int kullaniciID;
        private int seciliNotID = -1;

        Color normalBackColor;
        Color kilitliBackColor = Color.Gainsboro;

        public Form4(int girisYapanKullaniciID)
        {
            InitializeComponent();
            Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));

            kullaniciID = girisYapanKullaniciID;

            txtbaslik.Visible = false;
            txtnoticerik.Visible = false;
            gizlipanel.Visible = false;
            gizlipanel2.Visible = false;

            txtbaslik.ReadOnly = true;
            txtnoticerik.ReadOnly = true;

            normalBackColor = txtnoticerik.BackColor;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            EskiNotlariGridYukle();

            eskinotlargv.CellClick += Eskinotlargv_CellClick;

            // =========================
            // GRID GÖRÜNÜM AYARLARI
            // =========================

            // Fontlar
            eskinotlargv.DefaultCellStyle.Font = new Font("Segoe UI", 12F);
            eskinotlargv.ColumnHeadersDefaultCellStyle.Font =
                new Font("Segoe UI", 12F, FontStyle.Bold);

            // Satır yüksekliği
            eskinotlargv.RowTemplate.Height = 40;

            // Kolonlar alanı doldursun
            eskinotlargv.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            // Scroll ayarları
            eskinotlargv.ScrollBars = ScrollBars.Vertical;

            // Satır/kolon resize kapalı
            eskinotlargv.AllowUserToResizeRows = false;
            eskinotlargv.AllowUserToResizeColumns = false;

            // Satır başlığı gizle
            eskinotlargv.RowHeadersVisible = false;

            // Satır seçimi komple olsun
            eskinotlargv.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            eskinotlargv.MultiSelect = false;

            // Seçili satır rengi (hafif mavi, çok yakışıyor)
            eskinotlargv.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(220, 235, 255);
            eskinotlargv.DefaultCellStyle.SelectionForeColor =
                Color.Black;

            // Boş alan göze batmasın
            eskinotlargv.BackgroundColor = this.BackColor;
        }

        // =========================
        // GRID'E NOTLARI YÜKLE
        // =========================
        private void EskiNotlariGridYukle()
        {
            try
            {
                Class1 bgln = new Class1();
                using (SqlConnection conn = bgln.baglanti())
                {
                    conn.Open();

                    string q = @"
                SELECT 
                    NotID,
                    Baslik,
                    NotTarihi,
                    Kategori
                FROM Notlar
                WHERE KullaniciID = @k
                ORDER BY NotTarihi DESC";

                    SqlDataAdapter da = new SqlDataAdapter(q, conn);
                    da.SelectCommand.Parameters.AddWithValue("@k", kullaniciID);

                    tumNotlar = new DataTable();
                    da.Fill(tumNotlar);

                    eskinotlargv.DataSource = tumNotlar;

                    eskinotlargv.Columns["NotID"].Visible = false;
                    eskinotlargv.Columns["Baslik"].HeaderText = "Başlık";
                    eskinotlargv.Columns["NotTarihi"].HeaderText = "Tarih";
                    eskinotlargv.Columns["Kategori"].HeaderText = "Kategori";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Notlar yüklenemedi: " + ex.Message);
            }
        }

        // =========================
        // GRID TIKLAMA
        // =========================
        private void Eskinotlargv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            seciliNotID = Convert.ToInt32(
                eskinotlargv.Rows[e.RowIndex].Cells["NotID"].Value);

            NotuGetir(seciliNotID);
        }

        // =========================
        // NOT GETİR
        // =========================
        private void NotuGetir(int notID)
        {
            pictureBox3.Visible = true;
            try
            {
                Class1 bgln = new Class1();
                using (SqlConnection conn = bgln.baglanti())
                {
                    conn.Open();

                    string q = "SELECT Baslik, Icerik FROM Notlar WHERE NotID=@id";
                    using (SqlCommand cmd = new SqlCommand(q, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", notID);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                txtbaslik.Visible = true;
                                txtnoticerik.Visible = true;
                                gizlipanel.Visible = true;
                                gizlipanel2.Visible = true;
                                gizlipanel2.BringToFront();
                                

                                txtbaslik.Text = dr["Baslik"].ToString();
                                txtnoticerik.Text = dr["Icerik"].ToString();

                                txtbaslik.ReadOnly = true;
                                txtnoticerik.ReadOnly = true;

                                txtbaslik.BackColor = kilitliBackColor;
                                txtnoticerik.BackColor = kilitliBackColor;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not açılamadı: " + ex.Message);
            }
        }

        // =========================
        // BUGÜN İÇİN YAZ
        // =========================
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            seciliNotID = -1;

            txtbaslik.Visible = true;
            txtnoticerik.Visible = true;
            gizlipanel.Visible = true;
            pictureBox3.Visible = true;

            txtbaslik.ReadOnly = false;
            txtnoticerik.ReadOnly = false;

            txtbaslik.BackColor = normalBackColor;
            txtnoticerik.BackColor = normalBackColor;

            txtbaslik.Clear();
            txtnoticerik.Clear();
        }

        // =========================
        // KAYDET
        // =========================
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtbaslik.Text) ||
                string.IsNullOrWhiteSpace(txtnoticerik.Text) ||
                cmboxkategori.SelectedIndex == -1)
            {
                MessageBox.Show("Başlık, içerik ve kategori alanları boş olamaz",
                    "Hata",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                    );
                return;
            }

            try
            {
                Class1 bgln = new Class1();
                using (SqlConnection conn = bgln.baglanti())
                {
                    conn.Open();

                    string q = @"
                        INSERT INTO Notlar
                        (KullaniciID, Baslik, Icerik, NotTarihi, GuncellemeTarihi, Kategori)
                        VALUES
                        (@k,@b,@i,GETDATE(),GETDATE(), @kat)";  // Kategori sütunu eklendi ve varsayılan değer 'Genel' verildi

                    using (SqlCommand cmd = new SqlCommand(q, conn))
                    {
                        cmd.Parameters.AddWithValue("@k", kullaniciID);
                        cmd.Parameters.AddWithValue("@b", txtbaslik.Text);
                        cmd.Parameters.AddWithValue("@i", txtnoticerik.Text);
                        cmd.Parameters.AddWithValue("@kat", cmboxkategori.SelectedItem);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Not kaydedildi");
                EskiNotlariGridYukle();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        // =========================
        // DÜZENLE
        // =========================
        private void buttonduzenle_Click(object sender, EventArgs e)
        {
            if (seciliNotID == -1)
            {
                MessageBox.Show("Önce bir not seç");
                return;
            }

            txtbaslik.ReadOnly = false;
            txtnoticerik.ReadOnly = false;

            txtbaslik.BackColor = normalBackColor;
            txtnoticerik.BackColor = normalBackColor;
        }

        // =========================
        // GÜNCELLE
        // =========================
        private void buttonguncelle_Click(object sender, EventArgs e)
        {            
            if (seciliNotID == -1)
            {
                MessageBox.Show("Güncellenecek not yok!");
                return;
            }

            try
            {
                Class1 bgln = new Class1();
                using (SqlConnection conn = bgln.baglanti())
                {
                    conn.Open();

                    string q = @"
                        UPDATE Notlar
                        SET Baslik=@b,
                            Icerik=@i,
                            GuncellemeTarihi=GETDATE()
                        WHERE NotID=@id";

                    using (SqlCommand cmd = new SqlCommand(q, conn))
                    {
                        cmd.Parameters.AddWithValue("@b", txtbaslik.Text);
                        cmd.Parameters.AddWithValue("@i", txtnoticerik.Text);
                        cmd.Parameters.AddWithValue("@id", seciliNotID);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show(
                        "Güncelleme başarılıyla yapıldı",
                        "Başarılı",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                 );

                
                                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text Files (*.txt)|*.txt";
            sfd.FileName = DateTime.Today.ToString("yyyy-MM-dd") + ".txt";
            if (sfd.ShowDialog() == DialogResult.OK)
                File.WriteAllText(sfd.FileName, txtnoticerik.Text);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }
        private void EskiNotlariGridYukleFiltreli()
        {
            try
            {
                Class1 bgln = new Class1();
                using (SqlConnection conn = bgln.baglanti())
                {
                    conn.Open();

                    // Başlangıç sorgusu
                    string q = "SELECT NotID, Baslik, NotTarihi, Kategori FROM Notlar WHERE KullaniciID = @k";

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.Parameters.AddWithValue("@k", kullaniciID);

                    // 🔹 KATEGORİ FİLTRESİ (DÜZELTİLDİ: Seçili bir öğe VARSA filtrele)
                    if (cmbkategori.SelectedIndex != -1)
                    {
                        q += " AND Kategori = @kat";
                        cmd.Parameters.AddWithValue("@kat", cmbkategori.SelectedItem.ToString());
                    }

                    // 🔹 TARİH FİLTRESİ
                    if (dtBaslangic.Checked || dtBitis.Checked)
                    {
                        q += " AND NotTarihi BETWEEN @bas AND @bit";
                        cmd.Parameters.AddWithValue("@bas", dtBaslangic.Value.Date);
                        cmd.Parameters.AddWithValue("@bit", dtBitis.Value.Date.AddDays(1).AddSeconds(-1));
                    }

                    q += " ORDER BY NotTarihi DESC";
                    cmd.CommandText = q;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    eskinotlargv.DataSource = dt; // DataSource'u doğrudan bağlayın

                    if (eskinotlargv.Columns.Contains("NotID"))
                        eskinotlargv.Columns["NotID"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Filtreleme hatası: " + ex.Message);
            }
        }
        private void notarabutton_Click(object sender, EventArgs e)
        {
            EskiNotlariGridYukleFiltreli();
            if (tumNotlar == null) return;

            if (dtBaslangic.Value.Date > dtBitis.Value.Date)
            {
                MessageBox.Show("Tarih aralığı hatalı");
                return;
            }

            DataView dv = tumNotlar.DefaultView;

            string filtre = "1 = 1";

            // 🔹 KATEGORİ
            if (!string.IsNullOrWhiteSpace(cmbkategori.Text))
            {
                filtre += " AND Kategori = '" +
                          cmbkategori.Text.Replace("'", "''") + "'";
            }

            // 🔹 TARİH
            filtre += $" AND NotTarihi >= #{dtBaslangic.Value:yyyy-MM-dd}#";
            filtre += $" AND NotTarihi <= #{dtBitis.Value:yyyy-MM-dd}#";

            dv.RowFilter = filtre;
        }
        private void filtreTemizleButton_Click(object sender, EventArgs e)
        {
            if (tumNotlar == null) return;

            cmbkategori.SelectedIndex = -1;
            eskinotlargv.DataSource = tumNotlar;
        }

        int mouseX, mouseY;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseX = MousePosition.X - this.Left;
            mouseY = MousePosition.Y - this.Top;
            timer1.Enabled = true;
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            timer1.Enabled=false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            txtbaslik.Visible = false;
            txtnoticerik.Visible = false;
            gizlipanel.Visible = false;
            gizlipanel2.Visible = false;

            gizlipanel.Visible = false;
            txtbaslik.Visible = false;
            txtnoticerik.Visible = false;

            txtbaslik.ReadOnly = true;
            txtnoticerik.ReadOnly = true;

            txtbaslik.Clear();
            txtnoticerik.Clear();

            seciliNotID = -1;

            EskiNotlariGridYukle();
            eskinotlargv.ClearSelection();

            pictureBox3.Visible = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Left = MousePosition.X - mouseX;
            this.Top = MousePosition.Y - mouseY;this.Left = MousePosition.X - mouseX;
            this.Top = MousePosition.Y - mouseY;
        }
    }
}