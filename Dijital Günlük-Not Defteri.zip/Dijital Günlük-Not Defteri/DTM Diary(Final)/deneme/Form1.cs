﻿using System;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace deneme
{
    public partial class Form1 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );

        public Form1()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
        }

        int mouseX, mouseY;

        private void Form1_Load(object sender, EventArgs e)
        {
            guna2TextBox2.PasswordChar = '\u25CF'; // şifre gizleme
        }

        private void guna2Button1_Click(object sender, EventArgs e) // Giriş butonu
        {
            if (string.IsNullOrWhiteSpace(guna2TextBox1.Text) || string.IsNullOrWhiteSpace(guna2TextBox2.Text))
            {
                MessageBox.Show("Lütfen tüm alanları doldurunuz.", "Eksik Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                guna2TextBox1.Focus();
                return;
            }

            Class1 bgln = new Class1();
            try
            {
                using (SqlConnection baglanti = bgln.baglanti())
                {
                    baglanti.Open();

                    // Kullanıcı adı ve şifreyi kontrol et
                    string sorgu = "SELECT COUNT(*) FROM Kullanici_Bilgileri WHERE KullaniciAdi=@user AND Sifre=@pass";
                    using (SqlCommand kontrolCmd = new SqlCommand(sorgu, baglanti))
                    {
                        kontrolCmd.Parameters.AddWithValue("@user", guna2TextBox1.Text);
                        kontrolCmd.Parameters.AddWithValue("@pass", guna2TextBox2.Text);

                        int sonuc = (int)kontrolCmd.ExecuteScalar();

                        if (sonuc > 0)
                        {
                            // Kullanıcının gerçek ID'sini al
                            string sorguID = "SELECT KullaniciID FROM Kullanici_Bilgileri WHERE KullaniciAdi=@user AND Sifre=@pass";
                            int kullaniciID;
                            using (SqlCommand cmdID = new SqlCommand(sorguID, baglanti))
                            {
                                cmdID.Parameters.AddWithValue("@user", guna2TextBox1.Text);
                                cmdID.Parameters.AddWithValue("@pass", guna2TextBox2.Text);
                                kullaniciID = (int)cmdID.ExecuteScalar();
                            }

                            // Form4'ü açarken ID'yi gönder
                            this.Hide();
                            Form4 form4 = new Form4(kullaniciID);
                            form4.Show();
                        }
                        else
                        {
                            MessageBox.Show("Kullanıcı adı veya şifre hatalı. Lütfen tekrar deneyiniz.", "Giriş Başarısız", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            guna2TextBox1.Clear();
                            guna2TextBox2.Clear();
                            guna2TextBox1.Focus();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanı bağlantısı kurulamadı:\n" + ex.Message, "Bağlantı Hatası", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void guna2TextBox2_IconLeftClick(object sender, EventArgs e) // şifre göster/gizle
        {
            if (guna2TextBox2.PasswordChar == '\0')
            {
                guna2TextBox2.PasswordChar = '\u25CF';
            }
            else
            {
                guna2TextBox2.PasswordChar = '\0';
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e) // Kayıt ol
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void guna2Button3_Click(object sender, EventArgs e) // Şifremi unuttum
        {
            Form3 sifremi_unuttum = new Form3();
            sifremi_unuttum.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e) // Çıkış
        {
            Application.Exit();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e) // Form sürükleme
        {
            mouseX = MousePosition.X - this.Left;
            mouseY = MousePosition.Y - this.Top;
            timer1.Enabled = true;
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e) // Form sürükleme
        {
            timer1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e) // Form sürükleme
        {
            this.Left = MousePosition.X - mouseX;
            this.Top = MousePosition.Y - mouseY;
        }
    }
}