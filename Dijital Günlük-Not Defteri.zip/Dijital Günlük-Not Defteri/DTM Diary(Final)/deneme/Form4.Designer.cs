﻿namespace deneme
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.panelheader = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.gizlipanel = new System.Windows.Forms.Panel();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.lblkatagori = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmboxkategori = new System.Windows.Forms.ComboBox();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.gizlipanel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonguncelle = new Guna.UI2.WinForms.Guna2Button();
            this.buttonduzenle = new Guna.UI2.WinForms.Guna2Button();
            this.txtnoticerik = new System.Windows.Forms.RichTextBox();
            this.panelozellikler = new System.Windows.Forms.Panel();
            this.notarabutton = new Guna.UI2.WinForms.Guna2Button();
            this.cmbkategori = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtBitis = new System.Windows.Forms.DateTimePicker();
            this.dtBaslangic = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.txtbaslik = new Guna.UI2.WinForms.Guna2TextBox();
            this.panelnotlar = new System.Windows.Forms.Panel();
            this.eskinotlargv = new System.Windows.Forms.DataGridView();
            this.dtm_DiaryDataSet = new deneme.Dtm_DiaryDataSet();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelheader.SuspendLayout();
            this.gizlipanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.gizlipanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelozellikler.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelnotlar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eskinotlargv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtm_DiaryDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // panelheader
            // 
            this.panelheader.BackColor = System.Drawing.Color.Gainsboro;
            this.panelheader.Controls.Add(this.label1);
            this.panelheader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelheader.Location = new System.Drawing.Point(0, 24);
            this.panelheader.Name = "panelheader";
            this.panelheader.Size = new System.Drawing.Size(937, 75);
            this.panelheader.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.SteelBlue;
            this.label1.Location = new System.Drawing.Point(16, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bugün:";
            // 
            // gizlipanel
            // 
            this.gizlipanel.Controls.Add(this.gizlipanel2);
            this.gizlipanel.Controls.Add(this.guna2Button3);
            this.gizlipanel.Controls.Add(this.pictureBox6);
            this.gizlipanel.Controls.Add(this.lblkatagori);
            this.gizlipanel.Controls.Add(this.cmboxkategori);
            this.gizlipanel.Controls.Add(this.guna2Button2);
            this.gizlipanel.Location = new System.Drawing.Point(2, 1);
            this.gizlipanel.Name = "gizlipanel";
            this.gizlipanel.Size = new System.Drawing.Size(360, 555);
            this.gizlipanel.TabIndex = 9;
            this.gizlipanel.Visible = false;
            // 
            // guna2Button3
            // 
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.guna2Button3.ForeColor = System.Drawing.Color.SteelBlue;
            this.guna2Button3.Location = new System.Drawing.Point(104, 453);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(180, 45);
            this.guna2Button3.TabIndex = 30;
            this.guna2Button3.Text = "TXT Olarak İndir";
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(83, 159);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(212, 191);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 29;
            this.pictureBox6.TabStop = false;
            // 
            // lblkatagori
            // 
            this.lblkatagori.BackColor = System.Drawing.Color.Transparent;
            this.lblkatagori.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblkatagori.Location = new System.Drawing.Point(82, 34);
            this.lblkatagori.Name = "lblkatagori";
            this.lblkatagori.Size = new System.Drawing.Size(213, 32);
            this.lblkatagori.TabIndex = 3;
            this.lblkatagori.Text = "Kategoriler (Zorunlu)";
            // 
            // cmboxkategori
            // 
            this.cmboxkategori.FormattingEnabled = true;
            this.cmboxkategori.Items.AddRange(new object[] {
            "İş",
            "Ders",
            "Kişisel",
            "Sağlık",
            "Aile",
            "Hedefler",
            "Diğer"});
            this.cmboxkategori.Location = new System.Drawing.Point(82, 85);
            this.cmboxkategori.Name = "cmboxkategori";
            this.cmboxkategori.Size = new System.Drawing.Size(213, 21);
            this.cmboxkategori.TabIndex = 1;
            // 
            // guna2Button2
            // 
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.SteelBlue;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.Location = new System.Drawing.Point(104, 383);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(180, 45);
            this.guna2Button2.TabIndex = 0;
            this.guna2Button2.Text = "Kaydet";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // gizlipanel2
            // 
            this.gizlipanel2.Controls.Add(this.pictureBox2);
            this.gizlipanel2.Controls.Add(this.buttonguncelle);
            this.gizlipanel2.Controls.Add(this.buttonduzenle);
            this.gizlipanel2.Location = new System.Drawing.Point(9, 0);
            this.gizlipanel2.Name = "gizlipanel2";
            this.gizlipanel2.Size = new System.Drawing.Size(348, 542);
            this.gizlipanel2.TabIndex = 31;
            this.gizlipanel2.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(75, 88);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(212, 191);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // buttonguncelle
            // 
            this.buttonguncelle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonguncelle.BorderColor = System.Drawing.Color.White;
            this.buttonguncelle.BorderRadius = 10;
            this.buttonguncelle.BorderThickness = 1;
            this.buttonguncelle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonguncelle.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.buttonguncelle.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.buttonguncelle.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.buttonguncelle.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.buttonguncelle.FillColor = System.Drawing.Color.SteelBlue;
            this.buttonguncelle.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonguncelle.ForeColor = System.Drawing.Color.White;
            this.buttonguncelle.Image = ((System.Drawing.Image)(resources.GetObject("buttonguncelle.Image")));
            this.buttonguncelle.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.buttonguncelle.Location = new System.Drawing.Point(115, 426);
            this.buttonguncelle.Name = "buttonguncelle";
            this.buttonguncelle.Size = new System.Drawing.Size(128, 45);
            this.buttonguncelle.TabIndex = 1;
            this.buttonguncelle.Text = "Güncelle";
            this.buttonguncelle.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.buttonguncelle.Click += new System.EventHandler(this.buttonguncelle_Click);
            // 
            // buttonduzenle
            // 
            this.buttonduzenle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonduzenle.BorderColor = System.Drawing.Color.White;
            this.buttonduzenle.BorderRadius = 10;
            this.buttonduzenle.BorderThickness = 1;
            this.buttonduzenle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonduzenle.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.buttonduzenle.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.buttonduzenle.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.buttonduzenle.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.buttonduzenle.FillColor = System.Drawing.Color.SteelBlue;
            this.buttonduzenle.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonduzenle.ForeColor = System.Drawing.Color.White;
            this.buttonduzenle.Image = ((System.Drawing.Image)(resources.GetObject("buttonduzenle.Image")));
            this.buttonduzenle.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.buttonduzenle.Location = new System.Drawing.Point(115, 325);
            this.buttonduzenle.Name = "buttonduzenle";
            this.buttonduzenle.Size = new System.Drawing.Size(128, 45);
            this.buttonduzenle.TabIndex = 0;
            this.buttonduzenle.Text = "Düzenle";
            this.buttonduzenle.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.buttonduzenle.Click += new System.EventHandler(this.buttonduzenle_Click);
            // 
            // txtnoticerik
            // 
            this.txtnoticerik.Location = new System.Drawing.Point(0, 99);
            this.txtnoticerik.Name = "txtnoticerik";
            this.txtnoticerik.Size = new System.Drawing.Size(574, 441);
            this.txtnoticerik.TabIndex = 6;
            this.txtnoticerik.Text = "";
            this.txtnoticerik.Visible = false;
            // 
            // panelozellikler
            // 
            this.panelozellikler.BackColor = System.Drawing.Color.Gainsboro;
            this.panelozellikler.Controls.Add(this.gizlipanel);
            this.panelozellikler.Controls.Add(this.notarabutton);
            this.panelozellikler.Controls.Add(this.cmbkategori);
            this.panelozellikler.Controls.Add(this.label6);
            this.panelozellikler.Controls.Add(this.label5);
            this.panelozellikler.Controls.Add(this.label4);
            this.panelozellikler.Controls.Add(this.dtBitis);
            this.panelozellikler.Controls.Add(this.dtBaslangic);
            this.panelozellikler.Controls.Add(this.label3);
            this.panelozellikler.Controls.Add(this.label2);
            this.panelozellikler.Location = new System.Drawing.Point(576, 97);
            this.panelozellikler.Name = "panelozellikler";
            this.panelozellikler.Size = new System.Drawing.Size(360, 570);
            this.panelozellikler.TabIndex = 0;
            // 
            // notarabutton
            // 
            this.notarabutton.BorderColor = System.Drawing.Color.DarkGray;
            this.notarabutton.BorderRadius = 10;
            this.notarabutton.BorderThickness = 1;
            this.notarabutton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.notarabutton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.notarabutton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.notarabutton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.notarabutton.FillColor = System.Drawing.Color.WhiteSmoke;
            this.notarabutton.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.notarabutton.ForeColor = System.Drawing.Color.SteelBlue;
            this.notarabutton.Image = ((System.Drawing.Image)(resources.GetObject("notarabutton.Image")));
            this.notarabutton.Location = new System.Drawing.Point(178, 364);
            this.notarabutton.Name = "notarabutton";
            this.notarabutton.Size = new System.Drawing.Size(121, 45);
            this.notarabutton.TabIndex = 0;
            this.notarabutton.Text = "Not Ara";
            this.notarabutton.Click += new System.EventHandler(this.notarabutton_Click);
            // 
            // cmbkategori
            // 
            this.cmbkategori.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cmbkategori.FormattingEnabled = true;
            this.cmbkategori.Items.AddRange(new object[] {
            "İş",
            "Ders",
            "Kişisel",
            "Sağlık",
            "Aile",
            "Hedefler",
            "Diğer"});
            this.cmbkategori.Location = new System.Drawing.Point(65, 297);
            this.cmbkategori.Name = "cmbkategori";
            this.cmbkategori.Size = new System.Drawing.Size(121, 29);
            this.cmbkategori.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(66, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "Kategori:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label5.Location = new System.Drawing.Point(197, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "Bitiş";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(67, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 21);
            this.label4.TabIndex = 4;
            this.label4.Text = "Başlangıç";
            // 
            // dtBitis
            // 
            this.dtBitis.CalendarFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dtBitis.CalendarTitleBackColor = System.Drawing.Color.SteelBlue;
            this.dtBitis.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dtBitis.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtBitis.Location = new System.Drawing.Point(201, 187);
            this.dtBitis.Name = "dtBitis";
            this.dtBitis.Size = new System.Drawing.Size(101, 29);
            this.dtBitis.TabIndex = 3;
            // 
            // dtBaslangic
            // 
            this.dtBaslangic.CalendarFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dtBaslangic.CalendarTitleBackColor = System.Drawing.Color.SteelBlue;
            this.dtBaslangic.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dtBaslangic.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtBaslangic.Location = new System.Drawing.Point(71, 187);
            this.dtBaslangic.Name = "dtBaslangic";
            this.dtBaslangic.Size = new System.Drawing.Size(101, 29);
            this.dtBaslangic.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(63, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Tarih Aralığı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(61, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 37);
            this.label2.TabIndex = 0;
            this.label2.Text = "Filtre";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(937, 24);
            this.panel1.TabIndex = 39;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(4, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(24, 24);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(908, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderColor = System.Drawing.Color.Gray;
            this.guna2Button1.BorderRadius = 10;
            this.guna2Button1.BorderThickness = 1;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 14.25F);
            this.guna2Button1.ForeColor = System.Drawing.Color.SteelBlue;
            this.guna2Button1.Location = new System.Drawing.Point(23, 33);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(547, 59);
            this.guna2Button1.TabIndex = 3;
            this.guna2Button1.Text = "+ Bugün için yaz";
            this.guna2Button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // txtbaslik
            // 
            this.txtbaslik.BorderRadius = 10;
            this.txtbaslik.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbaslik.DefaultText = "";
            this.txtbaslik.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtbaslik.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtbaslik.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbaslik.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbaslik.FillColor = System.Drawing.Color.WhiteSmoke;
            this.txtbaslik.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtbaslik.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtbaslik.ForeColor = System.Drawing.Color.Black;
            this.txtbaslik.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtbaslik.Location = new System.Drawing.Point(4, 20);
            this.txtbaslik.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtbaslik.Name = "txtbaslik";
            this.txtbaslik.PlaceholderText = "Lütfen Başlık Giriniz (Zorunlu)";
            this.txtbaslik.SelectedText = "";
            this.txtbaslik.Size = new System.Drawing.Size(573, 72);
            this.txtbaslik.TabIndex = 0;
            this.txtbaslik.Visible = false;
            // 
            // panelnotlar
            // 
            this.panelnotlar.AutoScroll = true;
            this.panelnotlar.BackColor = System.Drawing.Color.Gainsboro;
            this.panelnotlar.Controls.Add(this.txtnoticerik);
            this.panelnotlar.Controls.Add(this.txtbaslik);
            this.panelnotlar.Controls.Add(this.eskinotlargv);
            this.panelnotlar.Controls.Add(this.guna2Button1);
            this.panelnotlar.Location = new System.Drawing.Point(0, 97);
            this.panelnotlar.Name = "panelnotlar";
            this.panelnotlar.Size = new System.Drawing.Size(577, 570);
            this.panelnotlar.TabIndex = 1;
            // 
            // eskinotlargv
            // 
            this.eskinotlargv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.eskinotlargv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.eskinotlargv.Location = new System.Drawing.Point(4, 99);
            this.eskinotlargv.Name = "eskinotlargv";
            this.eskinotlargv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.eskinotlargv.Size = new System.Drawing.Size(570, 441);
            this.eskinotlargv.TabIndex = 4;
            // 
            // dtm_DiaryDataSet
            // 
            this.dtm_DiaryDataSet.DataSetName = "Dtm_DiaryDataSet";
            this.dtm_DiaryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(937, 667);
            this.Controls.Add(this.panelozellikler);
            this.Controls.Add(this.panelnotlar);
            this.Controls.Add(this.panelheader);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panelheader.ResumeLayout(false);
            this.panelheader.PerformLayout();
            this.gizlipanel.ResumeLayout(false);
            this.gizlipanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.gizlipanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelozellikler.ResumeLayout(false);
            this.panelozellikler.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelnotlar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.eskinotlargv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtm_DiaryDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelheader;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Panel panelozellikler;
        private System.Windows.Forms.ComboBox cmbkategori;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtBitis;
        private System.Windows.Forms.DateTimePicker dtBaslangic;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox txtnoticerik;
        private System.Windows.Forms.Panel gizlipanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblkatagori;
        private System.Windows.Forms.ComboBox cmboxkategori;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TextBox txtbaslik;
        private System.Windows.Forms.Panel panelnotlar;
        private Guna.UI2.WinForms.Guna2Button buttonduzenle;
        private Guna.UI2.WinForms.Guna2Button buttonguncelle;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel gizlipanel2;
        private Dtm_DiaryDataSet dtm_DiaryDataSet;
        private System.Windows.Forms.DataGridView eskinotlargv;
        private Guna.UI2.WinForms.Guna2Button notarabutton;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}