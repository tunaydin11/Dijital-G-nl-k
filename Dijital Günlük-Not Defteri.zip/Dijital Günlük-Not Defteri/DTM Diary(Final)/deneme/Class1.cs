﻿using System.Data.SqlClient;

namespace deneme
{
    internal class Class1
    {
        public SqlConnection baglanti()
        {
            // Bağlantıyı döndürür, bağlantı açılmaz burada
            return new SqlConnection(
                @"Data Source=.\SQLEXPRESS;
                  Initial Catalog=Dtm_Diary;
                  Integrated Security=True;
                  TrustServerCertificate=True"
            );
        }

        // Opsiyonel: hızlı test için
        public bool TestConnection(out string mesaj)
        {
            try
            {
                using (SqlConnection conn = baglanti())
                {
                    conn.Open();
                    mesaj = "Bağlantı başarılı!";
                    return true;
                }
            }
            catch (SqlException ex)
            {
                mesaj = "Bağlantı hatası: " + ex.Message;
                return false;
            }
        }
    }
}
