﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace deneme
{
    public partial class Form3 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );

        public Form3()
        {
            InitializeComponent();
            Region = Region.FromHrgn(
                CreateRoundRectRgn(0, 0, Width, Height, 20, 20)
            );
        }

        int mouseX, mouseY;

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseX = MousePosition.X - this.Left;
            mouseY = MousePosition.Y - this.Top;
            timer1.Enabled = true;
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            timer1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Left = MousePosition.X - mouseX;
            this.Top = MousePosition.Y - mouseY;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Class1 bgln = new Class1();

            using (SqlConnection baglanti = bgln.baglanti())
            {
                string query = @"SELECT E_Posta, Ad, Soyad, Sifre
                                 FROM Kullanici_Bilgileri
                                 WHERE KullaniciAdi = @KullaniciAdi
                                   AND E_Posta = @EPosta";

                using (SqlCommand komut = new SqlCommand(query, baglanti))
                {
                    komut.Parameters.Add("@KullaniciAdi", SqlDbType.NVarChar)
                                     .Value = guna2TextBox1.Text.Trim();

                    komut.Parameters.Add("@EPosta", SqlDbType.NVarChar)
                                     .Value = guna2TextBox2.Text.Trim();

                    baglanti.Open(); // 🔴 KRİTİK

                    using (SqlDataReader oku = komut.ExecuteReader())
                    {
                        if (!oku.Read())
                        {
                            MessageBox.Show(
                                "Kullanıcı adı veya e-posta hatalı.",
                                "Uyarı",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning
                            );
                            return;
                        }

                        try
                        {
                            using (SmtpClient smtpserver = new SmtpClient("smtp.gmail.com", 587))
                            {
                                smtpserver.EnableSsl = true;
                                smtpserver.UseDefaultCredentials = false;
                                smtpserver.Credentials = new NetworkCredential(
                                    "mahmut.dastan.2552@gmail.com",
                                    "yijgkjnnbjzyslrk"
                                );

                                using (MailMessage mail = new MailMessage())
                                {
                                    mail.From = new MailAddress("dastanmahmutselim7@gmail.com");
                                    mail.To.Add(oku["E_Posta"].ToString());
                                    mail.Subject = "Şifre Hatırlatma Maili";
                                    mail.Body =
                                        $"Sayın {oku["Ad"]} {oku["Soyad"]}\n\n" +
                                        $"Şifreniz: {oku["Sifre"]}";
                                    mail.IsBodyHtml = false;

                                    smtpserver.Send(mail);
                                }
                            }

                            MessageBox.Show(
                                "Şifreniz mail adresinize gönderildi.",
                                "Bilgi",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information
                            );
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(
                                "Mail gönderilirken hata oluştu:\n" + ex.Message,
                                "Mail Hatası",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error
                            );
                        }
                    }
                }
            }
        }
    }
}