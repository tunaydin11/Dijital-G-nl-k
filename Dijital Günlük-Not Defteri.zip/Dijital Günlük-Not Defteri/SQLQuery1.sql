CREATE DATABASE Dtm_Diary;
GO

USE Dtm_Diary;
GO

CREATE TABLE Kullanici_Bilgileri
(
    KullaniciID INT IDENTITY(1,1) NOT NULL,
    KullaniciAdi NCHAR(20) NOT NULL,
    Ad NCHAR(20) NOT NULL,
    Soyad NCHAR(20) NOT NULL,
    Cinsiyet BIT NOT NULL,
    Sifre NCHAR(20) NOT NULL,
    E_Posta NCHAR(30) NOT NULL,

    CONSTRAINT PK_Kullanici_Bilgileri PRIMARY KEY (KullaniciID)
);
GO

CREATE TABLE Notlar
(
    NotID INT IDENTITY(1,1) NOT NULL,
    KullaniciID INT NOT NULL,
    Baslik NVARCHAR(100) NOT NULL,
    Icerik NVARCHAR(MAX) NOT NULL,
    Kategori NVARCHAR(50) NOT NULL,
    NotTarihi DATE NOT NULL,
    GuncellemeTarihi DATETIME NULL,

    CONSTRAINT PK_Notlar PRIMARY KEY (NotID),
    CONSTRAINT FK_Notlar_Kullanici
        FOREIGN KEY (KullaniciID)
        REFERENCES dbo.Kullanici_Bilgileri (KullaniciID)
);

GO